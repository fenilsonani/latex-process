# latex-process

A package to process LaTeX code and generate PDFs.

## Installation

```bash
pip install latex-process
```

## Usage

```bash
latex-process
```